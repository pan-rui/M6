CREATE PROCEDURE `p_clear_active2`()
  BEGIN
    DECLARE EXIT HANDLER FOR SQLWARNING,SQLEXCEPTION SET @info='execute error';
    SET @sqlStr ='UPDATE yanguan.YG_DEVICE_INFO ydi,(SELECT i.ICCID FROM yanguan.YG_DEVICE_INFO i  WHERE i.ICCID IS NOT NULL GROUP BY i.ICCID HAVING COUNT(1) >2) tm set ydi.Device_Active_Time=NULL WHERE ydi.ICCID = tm.ICCID ';
    PREPARE updateActive FROM @sqlStr;
    EXECUTE updateActive;
    #   UPDATE yanguan.YG_DEVICE_INFO ydi,@tableN gps  set ydi.Device_Active_Time=NULL WHERE ydi.Device_ID=gps.devId AND date(ydi.Device_Active_Time)=curdate() AND gps.gps_lng BETWEEN 114.0006 AND 114.0008 AND gps.gps_lat BETWEEN 22.6658 AND 22.6660;
    #   DELETE FROM @tableN WHERE gps_lng BETWEEN 114.0006 AND 114.0008 AND gps_lat BETWEEN 22.6658 AND 22.6660;
  END
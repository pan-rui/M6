CREATE PROCEDURE `p_summation_mileage`()
  BEGIN
    set SESSION SQL_MODE ='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
    INSERT IGNORE YG_WEEK_MILRAGE(Device_ID, Milage_Value, Ride_Time, Mean_Speed, Gps_Number, Create_Time, Number) SELECT tmp.Device_ID,tmp.Milage_Value,tmp.Ride_Time,tmp.Mean_Speed,tmp.Gps_Number,tmp.Create_Time,tmp.Day_Number FROM (SELECT count(DISTINCT Device_ID) countD,Device_ID,Milage_Value,Ride_Time,Mean_Speed,Gps_Number,Create_Time,Day_Number FROM
      YG_DAY_MILRAGE GROUP BY Device_ID HAVING dayofweek(Create_Time)!=1) tmp;
    INSERT IGNORE YG_MONTH_MILRAGE(Device_ID, Milage_Value, Ride_Time, Mean_Speed, Gps_Number,Create_Time) SELECT tmp.Device_ID,tmp.Milage_Value,tmp.Ride_Time,tmp.Mean_Speed,tmp.Gps_Number,tmp.Create_Time FROM (SELECT count(DISTINCT Device_ID) countD,Device_ID,Milage_Value,Ride_Time,Mean_Speed,Gps_Number,Create_Time,Day_Number FROM
      YG_DAY_MILRAGE GROUP BY Device_ID HAVING dayofmonth(Create_Time)!=1) tmp;
    INSERT IGNORE YG_TOTAL_MILRAGE(Device_ID, Milage_Value, Ride_Time, Mean_Speed, Gps_Number, Create_Time) SELECT tmp.Device_ID,tmp.Milage_Value,tmp.Ride_Time,tmp.Mean_Speed,tmp.Gps_Number,tmp.Create_Time FROM (SELECT count(DISTINCT Device_ID) countD,Device_ID,Milage_Value,Ride_Time,Mean_Speed,Gps_Number,Create_Time,Day_Number FROM
      YG_DAY_MILRAGE GROUP BY Device_ID) tmp;
    IF dayofweek(curdate())=2 THEN
      INSERT IGNORE YG_WEEK_MILRAGE(Device_ID, Milage_Value, Ride_Time, Mean_Speed, Gps_Number, Create_Time, Number)  SELECT Device_ID,Milage_Value,Ride_Time,Mean_Speed,Gps_Number,Create_Time,Day_Number FROM YG_DAY_MILRAGE WHERE dayofweek(Create_Time)=1;
    ELSE
      #       SELECT Device_ID,Milage_Value,Ride_Time,Mean_Speed,Gps_Number,Create_Time,Day_Number INTO @deviceId,@milageV,@rideT,@meanS,@gpsN,@createT,@dayN FROM YG_DAY_MILRAGE ORDER BY Create_Time DESC LIMIT 1;
      UPDATE YG_WEEK_MILRAGE ywm,YG_DAY_MILRAGE ydm SET ywm.Milage_Value=ywm.Milage_Value+ydm.Milage_Value,ywm.Ride_Time=ywm.Ride_Time+ydm.Ride_Time,ywm.Gps_Number=ywm.Gps_Number+ydm.Gps_Number WHERE ywm.Device_ID=ydm.Device_ID AND date_add(curdate(),INTERVAL -1 DAY)=date(ydm.Create_Time) AND ywm.Create_Time!=ydm.Create_Time AND week(ywm.Create_Time)=WEEK(ydm.Create_Time);
    END IF;
    IF DAYOFMONTH(curdate())=2 THEN
      INSERT IGNORE YG_MONTH_MILRAGE(Device_ID, Milage_Value, Ride_Time, Mean_Speed, Gps_Number, Create_Time)  SELECT Device_ID,Milage_Value,Ride_Time,Mean_Speed,Gps_Number,Create_Time FROM YG_DAY_MILRAGE WHERE dayofmonth(Create_Time)=1;
    ELSE
      UPDATE YG_MONTH_MILRAGE ywm,YG_DAY_MILRAGE ydm SET ywm.Milage_Value=ywm.Milage_Value+ydm.Milage_Value,ywm.Ride_Time=ywm.Ride_Time+ydm.Ride_Time,ywm.Gps_Number=ywm.Gps_Number+ydm.Gps_Number WHERE ywm.Device_ID=ydm.Device_ID AND date_add(curdate(),INTERVAL -1 DAY)=date(ydm.Create_Time) AND ywm.Create_Time!=ydm.Create_Time AND date_format(ywm.Create_Time,'%Y-%m')=date_format(ydm.Create_Time,'%Y-%m');
    END IF;
    UPDATE YG_TOTAL_MILRAGE ywm,YG_DAY_MILRAGE ydm SET ywm.Milage_Value=ywm.Milage_Value+ydm.Milage_Value,ywm.Ride_Time=ywm.Ride_Time+ydm.Ride_Time,ywm.Gps_Number=ywm.Gps_Number+ydm.Gps_Number WHERE ywm.Device_ID=ydm.Device_ID AND date_add(curdate(),INTERVAL -1 DAY)=date(ydm.Create_Time) AND ywm.Create_Time!=ydm.Create_Time;
  END
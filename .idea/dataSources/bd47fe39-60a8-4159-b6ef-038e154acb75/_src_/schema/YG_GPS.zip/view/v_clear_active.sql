CREATE VIEW `v_clear_active` AS
  SELECT
    `yanguan`.`YG_DEVICE_INFO`.`Device_ID`          AS `Device_ID`,
    `yanguan`.`YG_DEVICE_INFO`.`Device_Imei`        AS `Device_Imei`,
    `yanguan`.`YG_DEVICE_INFO`.`Device_Active_Time` AS `Device_Active_Time`
  FROM `yanguan`.`YG_DEVICE_INFO`
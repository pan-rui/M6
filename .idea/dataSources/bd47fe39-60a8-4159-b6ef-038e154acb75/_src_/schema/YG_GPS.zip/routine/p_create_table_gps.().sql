CREATE PROCEDURE `p_create_table_gps`()
  BEGIN
    DECLARE tableName VARCHAR(100);
    #     DECLARE table_name VARCHAR(100);
    #     DECLARE monthInt INT DEFAULT 1;
    #     DECLARE monthStr VARCHAR(16);
    DECLARE tableHeader VARCHAR(16);
    DECLARE tableBody VARCHAR(1024);
    DECLARE dropTableStr VARCHAR(255);
    DECLARE sqlStr VARCHAR(1000);
    SET tableName = CONCAT('YG_GPS.gps',DATE_FORMAT(NOW(),'%Y%m%d'));
    SET tableHeader = 'CREATE TABLE ';
    SET tableBody = '(`devId` INT(11) NOT NULL,`gps_lng` DOUBLE(9,6) NOT NULL COMMENT '经度',`gps_lat` DOUBLE(8,6) NOT NULL COMMENT '纬度',`speed` DOUBLE(6,3) NOT NULL COMMENT '速度',`direction` DOUBLE(6,3) NOT NULL COMMENT '方向',`time` DATETIME NOT NULL COMMENT '时间',PRIMARY KEY (`devId`,`time`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;';
    /*    WHILE monthInt <= 12 DO
          IF monthInt < 10 THEN
            SET monthStr = CONCAT('0',monthInt);
          ELSE
            SET monthStr = CONCAT(monthInt);
          END IF;*/
    #       SET table_name = CONCAT(tableName,monthStr);
    SET dropTableStr = CONCAT('DROP TABLE IF EXISTS ',tableName );
    SET sqlStr = CONCAT(tableHeader,tableName,tableBody);
    SELECT dropTableStr INTO @dropTableStr;
    SELECT sqlStr INTO @sqlStr;
    BEGIN
      PREPARE stepDropExistTable FROM @dropTableStr;
      EXECUTE stepDropExistTable;
      PREPARE stepCreateTbale FROM @sqlStr;
      EXECUTE stepCreateTbale;
    END;
    #       SET monthInt = monthInt + 1;
    #     END WHILE;
  END
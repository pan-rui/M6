CREATE PROCEDURE `p_clear_activeP`(`pdate` VARCHAR(16))
  BEGIN
    SET @sqlStr = concat('UPDATE YG_GPS.v_clear_active ydi,', DATE_FORMAT(date(pdate),'YG_GPS.gps%Y%m%d'),
                         ' gps  set ydi.Device_Active_Time=NULL WHERE ydi.Device_ID=gps.devId AND date(ydi.Device_Active_Time)=date("',pdate,'") AND gps.gps_lng BETWEEN 113.9890 AND 114.0050 AND gps.gps_lat BETWEEN 22.6600 AND 22.6690');
    PREPARE updateActive FROM @sqlStr;
    EXECUTE updateActive;
    #   UPDATE yanguan.YG_DEVICE_INFO ydi,@tableN gps  set ydi.Device_Active_Time=NULL WHERE ydi.Device_ID=gps.devId AND date(ydi.Device_Active_Time)=curdate() AND gps.gps_lng BETWEEN 114.0006 AND 114.0008 AND gps.gps_lat BETWEEN 22.6658 AND 22.6660;
    #   DELETE FROM @tableN WHERE gps_lng BETWEEN 114.0006 AND 114.0008 AND gps_lat BETWEEN 22.6658 AND 22.6660;
  END